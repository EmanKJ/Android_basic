package com.example.emanjustaniah

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.properties.Delegates

class MainActivity : AppCompatActivity() {
    //lateinit UI that we need to control them in this activity
    lateinit var deposit_text:EditText
    lateinit var withdraw_text:EditText
    lateinit var deposit_button:Button
    lateinit var withdrwa_button:Button
    lateinit var view_balance:TextView
    //----------------------------------------------------
    private lateinit var sharedPreferences: SharedPreferences
    //-----------------------------------------------------
    var amouont by Delegates.notNull<Float>() //this variable store the amount of many user entered in the edit text
    var balance=0f//This variable store the balance of the user
    lateinit var messages:Array<String>
    lateinit var  my_adp:RecyclerViewAdapter
    //Define an object from our recycler adapter class



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        get_pref()
        //Getting access through UI
        deposit_text=findViewById(R.id.deposit_text)
        deposit_button=findViewById(R.id.deposit)
        withdraw_text=findViewById(R.id.withdraw_text)
        withdrwa_button=findViewById(R.id.withdraw)
        view_balance=findViewById(R.id.balance)
        //-------------------------------------------

        messages = arrayOf("");//This to intilize the recycler view object
        var new_message:String

        val myRV=findViewById<RecyclerView>(R.id.rvMain)//Access the recycler view

        my_adp= RecyclerViewAdapter(messages)
        myRV.adapter= my_adp
        myRV.layoutManager= LinearLayoutManager(this)

        //----------------------------------------------
        deposit_button.setOnClickListener(){
            if (check_input(deposit_text)!=null){
                new_message="Deposit: $amouont"
                balance+=amouont
                view_balance.text="Current Balance: $balance"
                messages+=new_message
                my_adp.updateList(messages)
                myRV.smoothScrollToPosition(messages.size)//this perform auto scroll when the user enter new operation
            }
            deposit_text.text= null
            set_color(view_balance)
            //Use shared preferences to save the balance
           save_pref()//save preferences every time  user enter the button
        }

        //------------------------
        withdrwa_button.setOnClickListener(){
            if(balance<=0){
                Toast.makeText(this@MainActivity, "Sorry! you cant withdraw, your balance is $balance", Toast.LENGTH_LONG)
                    .show()
                withdraw_text.text = null
            }
            else {
                if (check_input(withdraw_text) != null) {
                    new_message = "Withdraw: $amouont"
                    balance -= amouont
                    if(balance<0){//overdraft charge of $20 should be added (only if balance is below 0)
                        balance -=20
                        view_balance.setTextColor(Color.RED)
                        Toast.makeText(this@MainActivity, "Overdraft charge of \$20 add because you withdraws more than you have", Toast.LENGTH_LONG)
                            .show()
                    }
                    else{ view_balance.setTextColor(Color.BLACK)}
                    view_balance.text = "Current Balance: $balance"
                    messages += new_message
                    my_adp.updateList(messages)
                    myRV.smoothScrollToPosition(messages.size)//this perform auto scroll when the user enter new operation

                }
                withdraw_text.text = null
            }//end of else
            //Use shared preferences to save the balance
            save_pref()//save preferences every time  user enter the button
        }


    }//End of onCreate function


    fun check_input(view:EditText) : Float? {//This method will check if the user inter number or not
        try {
            amouont = view.text.toString().toFloat();
            return amouont
        } catch (e: Exception) {

            Toast.makeText(this@MainActivity, "You can only enter numbers", Toast.LENGTH_LONG)
                .show()
        }
        return null


    }
    //================
    //This fucntion to set the appoprite color
    fun set_color(view:TextView){
        if (balance>=0){
            view.setTextColor(Color.BLACK)
        }
        else{view.setTextColor(Color.RED)}
    }
//=======================================================
    //override onStart & onResume functions to restore states
override fun onStart() {
    super.onStart()
    view_balance.text = "Current Balance: $balance"
    my_adp.updateList(messages)
    set_color(view_balance)
}

    override fun onResume() {
        super.onResume()
        view_balance.text = "Current Balance: $balance"
        my_adp.updateList(messages)
        set_color(view_balance)
    }
//***********************************************************


    //Save & restore instent state
    //This function to save instance state
    //I want to save the  balance and the messages that was in the screen
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putStringArray("messages",messages)
        outState.putFloat("balance",balance)
        //outState.putStringArrayList("myMessage", myMessage)
    }
    //-----------------------------
    //This function to restore instance state
    //I want to restore balance and the messages that was in the screen
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        balance= savedInstanceState.getFloat("balance", 0f)
        messages= savedInstanceState.getStringArray("messages") as Array<String>
    }

//******************************************************************************
//******************************************************************************
//Black belt requirements:
//******************************************************************************
//***********************************One****************************************
//******************************************************************************
//Using shared preferences property to store user balance
//save and share preferences:
fun save_pref(){
    with(sharedPreferences.edit()) {
        putFloat("balance", balance)

        apply()
    }
}
    //get user data
    fun get_pref(){

        sharedPreferences = this.getSharedPreferences(
            getString(R.string.preference_file_key), Context.MODE_PRIVATE)
        balance = sharedPreferences.getFloat("balance", 0f)  // --> retrieves data from Shared Preferences
    }
//******************************************************************************
//***********************************Two****************************************
//******************************************************************************
//Allow users to clear the ledger with a menu option, do not change the balance

    //This function makes the menu appear to the user:
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }
    //This function specify the action that will happen when the user click on item of the menu:
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.option1 -> {
                messages=arrayOf("")
                my_adp.updateList(messages)
            }

        }
        return super.onOptionsItemSelected(item)
    }



}//End of the class