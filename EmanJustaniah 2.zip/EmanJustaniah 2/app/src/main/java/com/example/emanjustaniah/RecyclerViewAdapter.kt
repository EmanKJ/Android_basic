package com.example.emanjustaniah

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ScrollCaptureCallback
import android.view.ScrollCaptureTarget
import android.view.View
import android.view.ViewGroup
import android.widget.Scroller
import androidx.appcompat.widget.ScrollingTabContainerView
import androidx.core.widget.AutoScrollHelper
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2.ScrollState
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.item_row.view.*

class RecyclerViewAdapter (private var messages:Array<String>): RecyclerView.Adapter<RecyclerViewAdapter.ItemViewHolder>(){
    class ItemViewHolder (itemView: View):RecyclerView.ViewHolder(itemView){

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        return ItemViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.item_row,
                parent,
                false,
                //smoothScrollToPosition(adapter.getItemCount() - 1)
            )
        )
        //recyclerView.smoothScrollToPosition(adapter.getItemCount() - 1)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
       val message=messages[position]

        holder.itemView.apply {
            if(message.startsWith("Withdraw:")){
                screen.setTextColor(Color.BLACK)
            }
            else if(message.startsWith("Deposit:")){
                screen.setTextColor(Color.BLUE)
            }

            screen.text=message





        }
    }

    //this function will be called every time we need to update the vlaue of messages
    fun updateList(new_messages:Array<String>, ){
        messages=new_messages



        notifyDataSetChanged()


    }

    override fun getItemCount()= messages.size
    //========================================

}